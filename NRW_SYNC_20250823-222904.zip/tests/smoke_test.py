import json, os, sys

def must_json(path):
    assert os.path.exists(path), f"missing {path}"
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert isinstance(data, list), f"{path} must be a list"
    return data

def test_baseline():
    base = must_json("output/data.json")
    assert len(base) >= 1, "baseline should contain at least 1 item"

def test_core_optional():
    if os.path.exists("output/data_core.json"):
        core = must_json("output/data_core.json")
        assert all(isinstance(x, dict) for x in core), "core must be list[dict]"

if __name__ == "__main__":
    try:
        test_baseline()
        test_core_optional()
        print("SMOKE: ok")
    except AssertionError as e:
        print("SMOKE: fail:", e)
        sys.exit(1)